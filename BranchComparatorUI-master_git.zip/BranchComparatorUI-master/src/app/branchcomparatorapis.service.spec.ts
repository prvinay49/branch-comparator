import { TestBed } from '@angular/core/testing';

import { BranchcomparatorapisService } from './branchcomparatorapis.service';

describe('BranchcomparatorapisService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BranchcomparatorapisService = TestBed.get(BranchcomparatorapisService);
    expect(service).toBeTruthy();
  });
});
