import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { BranchcomparatorComponent } from './branchcomparator/branchcomparator.component';
import { DevicesComponent } from './devices/devices.component';

const routes: Routes = [
  {path: 'compare', component: BranchcomparatorComponent, canActivate: [ MsalGuard ]},
  {path: 'devices', component: DevicesComponent, canActivate: [ MsalGuard ]},
  {path: '**', redirectTo: 'compare', canActivate: [ MsalGuard ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
