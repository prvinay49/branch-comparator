import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private results = new BehaviorSubject([]);
  currentResults = this.results.asObservable();

  constructor() { }

  updateResults(results: any) {
    this.results.next(results);
  }
}
