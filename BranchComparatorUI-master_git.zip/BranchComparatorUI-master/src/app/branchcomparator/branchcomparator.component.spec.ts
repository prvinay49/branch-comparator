import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchcomparatorComponent } from './branchcomparator.component';

describe('BranchcomparatorComponent', () => {
  let component: BranchcomparatorComponent;
  let fixture: ComponentFixture<BranchcomparatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchcomparatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchcomparatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
