import { Component, OnInit, Inject } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { MatSnackBar, MatAutocompleteModule } from '@angular/material';
import { BranchcomparatorapisService } from '../branchcomparatorapis.service';
import { DataService } from '../data.service';

import {Observable} from 'rxjs';

@Component({
  selector: 'app-branchcomparator',
  templateUrl: './branchcomparator.component.html',
  styleUrls: ['./branchcomparator.component.css']
})
export class BranchcomparatorComponent implements OnInit {

  //HOST = 'http://127.0.0.1:5000';
  //HOST = 'http://10.6.15.26:8000';
  HOST = 'https://10.6.5.163:5000';

  title = 'branchcomparator';
  device_type = '';
  run_type = 'branch';
  version = '';
  target_branch = '';
  running_script = false;
  button_text = 'Generate';
  rdkv_devices = [];
  rdkb_devices = [];
  xhome_devices = [];
  //versionValidator = new RegExp('^([0-9]+\.[0-9]+((p[0-9]+s[0-9]+)|(s[0-9]+)))$');

  project_specific = 'no';
  own_manifest = 'no';
  source_release_tag = '';
  target_release_tag = '';
  project_name = '';
  manifest_file = ''

  selected_devices = {
    video: {},
    broadband: {},
    xhome: {}
  };

  cred = {
    username: '',
    password: '',
    username1: '',
    password1: ''
  };

  results = [];

  validator = {
    invalid_version: false,
  };

  start_date = '';
  end_date = '';
  device_specific_type = '';
  timezone_val='utc';
  gerrit_option='ccp'

  postData = {};
  selected_device_release = '';
  branch_report_type = 'missing';
  release_report_type = 'missing';
  releaseTagOptions: string[] = [];
  filteredOptions: string[] = [];
  filteredOptions1: string[] = [];


  constructor(
    private rba: BranchcomparatorapisService,
    public snackBar: MatSnackBar,
    public dialog: MatDialog,
    private dataService: DataService) {
  }

  ngOnInit() {
    this.rba.getDeviceDetails().subscribe((data: any) => {
      this.rdkv_devices = data.rdkv_devices;
      this.rdkb_devices = data.rdkb_devices;
      this.xhome_devices = data.xhome_devices;
    });
    this.dataService.currentResults.subscribe(results => {
      this.results = results;
    });
  }

  getFilterOptions(val){
    if(val){
        return this._filter(val);
    }
    return this.releaseTagOptions;
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.releaseTagOptions.filter(option => option.toLowerCase().includes(filterValue));
    //return this.releaseTagOptions.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }

  getReleaseTags(device: string){
    this.source_release_tag = '';
    this.target_release_tag = '';
     this.releaseTagOptions = [];
     this.filteredOptions = [];
     this.filteredOptions1 = [];
    this.rba.getReleaseTags(device).subscribe((data: any) => {
      this.releaseTagOptions = data;
      this.filteredOptions = this.releaseTagOptions;
      this.filteredOptions1 = this.releaseTagOptions;
    },(error: any) => {
        this.releaseTagOptions = [];
    });
  }

  openDialog(): void {
    const dialodRef = this.dialog.open(StatusDialogComponent, {
      width: '2500px',
      data: this.results
    });
  }

  openStatus(statusParam: boolean, messageParam: string): void {
    const dialodRef = this.dialog.open(ExecutionStatusDialogComponent, {
      width: '250px',
      data: {
        status: statusParam,
        message: messageParam
      }
    });
  }

  reset(dType: string) {
    this.device_specific_type='specific_devices';
    this.selected_device_release='';
    if (dType === 'rdkv') {
      this.selected_devices.broadband = {};
      this.selected_devices.xhome = {};
    } else if (dType === 'rdkb') {
      this.selected_devices.video = {};
      this.selected_devices.xhome = {};
    } else if (dType === 'xhome') {
      this.selected_devices.video = {};
      this.selected_devices.broadband = {};
    } else {
      this.selected_devices.video = {};
      this.selected_devices.broadband = {};
      this.selected_devices.xhome = {};
    }
  }

  checkAll(){
    if(this.device_type == 'rdkv'){
        //this.selected_devices.video = {};
        this.selected_devices.broadband = {};
        this.selected_devices.xhome = {};
        for(const devi in this.rdkv_devices){
            this.selected_devices.video[this.rdkv_devices[devi]] = true;
        }
    }else if (this.device_type === 'rdkb'){
        //this.selected_devices.broadband = {};
        this.selected_devices.video = {};
        this.selected_devices.xhome = {};
        for(const devi in this.rdkb_devices){
            this.selected_devices.broadband[this.rdkb_devices[devi]] = true;
        }
    }else if (this.device_type === 'xhome'){
        //this.selected_devices.xhome = {};
        this.selected_devices.broadband = {};
        this.selected_devices.video = {};
        for(const devi in this.xhome_devices){
            this.selected_devices.xhome[this.xhome_devices[devi]] = true;
        }
    }
  }

  noDeviceSelected(): boolean {
    const ref = {
      rdkv: 'video',
      rdkb: 'broadband',
      xhome: 'xhome'
    };
    for (const entry in this.selected_devices[ref[this.device_type]]) {
      if (this.selected_devices[ref[this.device_type]][entry]) {
        return false;
      }
    }
    return true;
  }

  submit(rbForm: NgForm): any {
      this.validator.invalid_version = false;
      if (this.run_type=='branch' && this.noDeviceSelected()) {
        this.snackBar.open('Please select the devices to compare the branch.', 'X', {
          duration: 10000
        });
      } else if(this.run_type=='release' && this.source_release_tag == this.target_release_tag){
            this.snackBar.open('Please check your input!! Source tag is same as target.', 'X', {
                duration: 10000
            });
      }else {
        this.running_script = true;
        this.button_text = 'Generating...';
        const postData = {};
        if (this.run_type=='release'){
             this.postData = {
                source_release_tag: this.source_release_tag,
                target_release_tag: this.target_release_tag,
                selected_device_release: this.selected_device_release,
                gerrit_option: this.gerrit_option,
                release_report_type: this.release_report_type,
            }
            if(this.project_name!='' && this.project_specific=='yes'){
                this.postData['project_name'] = this.project_name
            }
            if(this.manifest_file!='' && this.own_manifest=='yes'){
                this.postData['manifest_file'] = this.manifest_file
            }
        }else{
            this.postData = {
              source: this.version,
              target: this.target_branch,
              start: this.start_date,
              end: this.end_date,
              devices: this.selected_devices,
              device_type: this.device_type,
              device_specific_type: this.device_specific_type,
              timezone_val: this.timezone_val,
              gerrit_option: this.gerrit_option,
              branch_report_type: this.branch_report_type,
         }
        }
    this.rba.compareBranches(this.postData, this.cred).subscribe((data: any) => {
          this.running_script = false;
          this.button_text = 'Generate';
          if (data['error'] != undefined){
            this.openStatus(false, data['error']);
          }else{
              if(data.primary_gerrit.changes.length ==0 && data.rdk_gerrit.changes.length==0){
                this.openStatus(true, 'No results found!');
              }else{
                  this.openStatus(true, 'Please check the results!');
                  if (this.run_type == 'branch'){
                      this.results.push(
                        {
                          device_type: this.device_type,
                          source: this.version,
                          target: this.target_branch,
                          start: this.start_date,
                          end: this.end_date,
                          device_specific_type: this.device_specific_type,
                          devices: this.selected_devices,
                          datetime: new Date(),
                          result: data,
                          run_type: this.run_type,
                          host: this.HOST,
                          notification: true
                        }
                      );
                  }else{
                    this.results.push(
                        {
                          device_type: this.device_type,
                          source: this.source_release_tag,
                          target: this.target_release_tag,
                          selected_device_release: this.selected_device_release,
                          release_report_type: this.release_report_type,
                          datetime: new Date(),
                          run_type: this.run_type,
                          result: data,
                          host: this.HOST,
                          notification: true
                        }
                      );

                  }
                  this.dataService.updateResults(this.results);
              }
          }
        },
        (error: any) => {
          this.running_script = false;
          this.button_text = 'Generate';
          if (error.status === 500) {
            /*
            this.snackBar.open('Invalid username or password!', 'X', {
              duration: 10000
            });
            */
            this.openStatus(false, 'Invalid username or password!');
          }
        });
      }
  }
}

@Component({
  selector: 'status-dialog',
  templateUrl: 'status-dialog.html'
})
export class StatusDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<StatusDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public snackBar: MatSnackBar) {

  }
  ref = {
    rdkv: 'video',
    rdkb: 'broadband',
    xhome: 'xhome'
  };
  getMainPage(result) {
    return Object.keys(result.result.data[this.ref[result.device_type]]).filter(key => key !== 'url')[0];
  }
  getMainPageUrl(result) {
    return result.result.data[this.ref[result.device_type]].url;
  }
  getVersionPage(result) {
    return Object.keys(result.result.data[this.ref[result.device_type]][this.getMainPage(result)]).filter(key => key !== 'url')[0];
  }
  getVersionPageUrl(result) {
    return result.result.data[this.ref[result.device_type]][this.getMainPage(result)].url;
  }
  copyMessage(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.snackBar.open('Link copied!', '', {
      duration: 1000
    });
  }

}

@Component({
  selector: 'execution-status-dialog',
  templateUrl: 'execution-status-dialog.html',
  styleUrls: ['./branchcomparator.component.css']
})
export class ExecutionStatusDialogComponent implements OnInit {
  status = '';
  constructor(
    public dialogRef: MatDialogRef<StatusDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
    ) {}

  ngOnInit() {
    if (this.data.status) {
      this.status = 'success';
    } else {
      this.status = 'danger';
    }
  }

}


import { PipeTransform, Pipe } from '@angular/core';

@Pipe({ name: 'highlight' })
export class HighlightPipe implements PipeTransform {
  transform(text: string, search): string {
    const pattern = search
      .replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&")
      .split(' ')
      .filter(t => t.length > 0)
      .join('|');
    const regex = new RegExp(pattern, 'gi');

    return search ? text.replace(regex, match => `<b>${match}</b>`) : text;
  }
}
