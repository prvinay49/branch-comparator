import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { Logger, CryptoUtils } from 'msal'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private router: Router, private broadcastService: BroadcastService,
  private authService: MsalService) { }

  isHomeRoute() {
    return this.router.url === '/';
  }

  isIframe = false;
  loggedIn = false;
  authInfo;
  name='';
  username='';

  ngOnInit() {
    this.isIframe = window !== window.parent && !window.opener;

    this.authInfo  = this.checkAccount();

    this.name = this.authInfo.name;
    this.username = this.authInfo.userName;

    console.log(this.authInfo)

    this.broadcastService.subscribe('msal:loginSuccess', () => {
      this.checkAccount();
    });

    this.authService.handleRedirectCallback((authError, response) => {
      if (authError) {
        console.error('Redirect Error: ', authError.errorMessage);
        return;
      }

      console.log('Redirect Success: ', response.accessToken);
    });

    this.authService.setLogger(new Logger((logLevel, message, piiEnabled) => {
      console.log('MSAL Logging: ', message);
    }, {
      correlationId: CryptoUtils.createNewGuid(),
      piiLoggingEnabled: false
    }));

  }

  checkAccount() {
    const authInfo = this.authService.getAccount()
    this.loggedIn = !!authInfo;
    return authInfo;
  }

  login() {
    const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

    if (isIE) {
      this.authService.loginRedirect();
    } else {
      this.authService.loginPopup();
    }
  }

  logout() {
    this.authService.logout();
  }

}