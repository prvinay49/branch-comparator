import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewDeviceComponent } from './devices/new-device/new-device.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppMaterialModule } from './app-material/app-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { MSAL_CONFIG, MSAL_CONFIG_ANGULAR, MsalAngularConfiguration, MsalService } from "@azure/msal-angular";
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MatSelectModule, MatRippleModule, MatDatepickerModule, MatNativeDateModule, MatAutocompleteModule } from '@angular/material';
import { NgxMatNativeDateModule, NgxMatDatetimePickerModule, NgxMatTimepickerModule }
from '@angular-material-components/datetime-picker';


import { BranchcomparatorapisService } from './branchcomparatorapis.service';
import { DataService } from './data.service';
import {
  BranchcomparatorComponent,
  StatusDialogComponent,
  ExecutionStatusDialogComponent,
  HighlightPipe,
} from './branchcomparator/branchcomparator.component';
import { DevicesComponent, ExecutionStatusDialogComponentNew } from './devices/devices.component';


import { environment } from '../environments/environment';
import { Configuration } from 'msal';

export function MSALConfigFactory(): Configuration {
  return {
    auth: {
      clientId: environment.clientId,
      authority: environment.authority,
      validateAuthority: true,
      redirectUri: environment.redirectUrl,
      postLogoutRedirectUri: environment.redirectUrl,
      navigateToLoginRequestUrl: true,
    },
    cache: {
      storeAuthStateInCookie: false,
    }
  };
}

export function MSALAngularConfigFactory(): MsalAngularConfiguration {
  return {
    popUp: false
  };
}


@NgModule({
  declarations: [
    AppComponent,
    BranchcomparatorComponent,
    DevicesComponent,
    NewDeviceComponent,
    StatusDialogComponent,
    ExecutionStatusDialogComponent,
    ExecutionStatusDialogComponentNew,
    HighlightPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AppMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MsalModule,
    AngularFontAwesomeModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    NgxMatNativeDateModule,
    NgxMatTimepickerModule,
    NgxMatDatetimePickerModule,
    MatAutocompleteModule,
  ],
  providers: [
    BranchcomparatorapisService,
    DataService,
    {
      provide: MSAL_CONFIG,
      useFactory: MSALConfigFactory
    },
    {
      provide: MSAL_CONFIG_ANGULAR,
      useFactory: MSALAngularConfigFactory
    },
    MsalService
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    StatusDialogComponent,
    ExecutionStatusDialogComponent,
    ExecutionStatusDialogComponentNew
  ]
})
export class AppModule { }
