import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BranchcomparatorapisService {
  constructor(private httpClient: HttpClient) { }

  //HOST = 'http://127.0.0.1:5000';
  //HOST = 'http://10.6.15.26:8000';
  HOST = 'https://10.6.5.163:5000';

  compareBranches(data: any, cred: any): Observable<any> {
    //console.log(data.copy_version);
    let httpHeader = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Basic ' + btoa(cred.username + ':' + cred.password),
      'RDK-CENTRAL': 'Basic ' + btoa(cred.username1 + ':' + cred.password1)
    });
    const httpOptions = {
      headers: httpHeader
    };
    if (data['source_release_tag']){
        return this.httpClient.post<any>(this.HOST+'/compare_release', data, httpOptions);
    }else{
        return this.httpClient.post<any>(this.HOST+'/compare_branch', data, httpOptions);
    }
  }

  addDevice(deviceData: any): Observable<any> {
    const httpHeader = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    const httpOptions = {
      headers: httpHeader
    };
    return this.httpClient.post<any>(this.HOST+'/add_device', deviceData, httpOptions);
  }

  getDeviceDetails(): Observable<any> {
    return this.httpClient.get<any>(this.HOST+'/getdevicedetails');
  }

  getDeviceManifestDetails(device_name:any): Observable<any> {
    return this.httpClient.get<any>(this.HOST+'/get_device_manifest_detail?device_name='+device_name);
  }

  getReleaseTags(device_name:any): Observable<any> {
    return this.httpClient.get<any>(this.HOST+'/get_tags?device_name='+device_name);
  }

  getMapDetails(): Observable<any> {
    return this.httpClient.get<any>(this.HOST+'/get_project_map');
  }

  updateDeviceDetails(data: any): Observable<any> {
    return this.httpClient.post<any>(this.HOST+'/update_device_details', data);
  }

  updateMapDetails(data: any): Observable<any> {
    return this.httpClient.post<any>(this.HOST+'/update_project_map', data);
  }
}
