import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, OnInit, Inject } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material';

import { BranchcomparatorapisService } from '../branchcomparatorapis.service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css']
})
export class DevicesComponent implements OnInit {

  devices:any;
  map:any;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  buttonText = 'Update';
  updating = false;
  results = [];
  constructor(private rba: BranchcomparatorapisService,
  public dialog: MatDialog,
  public snackBar: MatSnackBar) { }

  ngOnInit() {
    this.loadDevices();
  }

  loadDevices() {
    this.rba.getDeviceDetails().subscribe((data: any) => {
      this.devices = data;
      this.rba.getMapDetails().subscribe((mapData: any) => {
        this.map = mapData;
      });
    });
  }

  openDialog(): void {
    const dialodRef = this.dialog.open(StatusDialogComponent, {
      width: '2500px',
      data: this.results
    });
  }

  openStatus(statusParam: boolean, messageParam: string): void {
    const dialodRef = this.dialog.open(ExecutionStatusDialogComponentNew, {
      width: '250px',
      data: {
        status: statusParam,
        message: messageParam
      }
    });
  }

  snack(message: string, time: number) {
    this.snackBar.open(message, '', {
      duration: time
    });
  }

  remove(device: any, type: string): void {
    const index = this.devices[type].indexOf(device);
    const dict = {
      rdkv_devices: 'video',
      rdkb_devices: 'broadband',
      xhome_devices: 'xhome'
    };

    if (index >= 0) {
      this.devices[type].splice(index, 1);
      if (type === 'rdkb_devices') {
        delete this.map[dict[type]][device];
      }
    }
  }

  show_dev_detail(device): void{
    this.rba.getDeviceManifestDetails(device).subscribe((data: any) => {
      if (data.status === 'success') {
        const msg_str = '"Project":'+data.data['project']+'\n'
        +'"Manifest file":'+data.data['manifest_file']+
        '\n'+'"Model name":'+data.data['model_name'];
        this.openStatus(true, '"Device name":'+device+'\n'+msg_str);
      }else{
        this.snack('Unable to get device detail!', 3000);
      }
  },
    (error: any) => {
      this.snack('Unable to get device detail!', 3000);
    });
  }

  update_devices(): void {
    this.updating = true;
    this.rba.updateDeviceDetails(this.devices).subscribe((data: any) => {
      if (data.status === 'success') {
        this.rba.updateMapDetails(this.map).subscribe((mapData: any) => {
          if (mapData.status === 'success') {
            this.snack('Updated successfully!', 3000);
            this.updating = false;
          }
        },
        (error: any) => {
          this.snack('Error occurred!', 3000);
          this.updating = false;
        });
      }
    },
    (error: any) => {
      this.snack('Error occurred!', 3000);
      this.updating = false;
    });
  }
}

export class StatusDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<StatusDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public snackBar: MatSnackBar) {

  }

}

@Component({
  selector: 'execution-status-dialog',
  templateUrl: '../branchcomparator/execution-status-dialog.html',
  styleUrls: ['../branchcomparator/branchcomparator.component.css']
})
export class ExecutionStatusDialogComponentNew implements OnInit {
  status = '';
  constructor(
    public dialogRef: MatDialogRef<StatusDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
    ) {}

  ngOnInit() {
    if (this.data.status) {
      this.status = 'success';
    } else {
      this.status = 'danger';
    }
  }

}
