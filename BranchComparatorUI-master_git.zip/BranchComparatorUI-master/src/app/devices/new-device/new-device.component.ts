import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { MatSnackBar } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { BranchcomparatorapisService } from '../../branchcomparatorapis.service';
import { ExecutionStatusDialogComponent } from '../../branchcomparator/branchcomparator.component';

@Component({
  selector: 'app-new-device',
  templateUrl: './new-device.component.html',
  styleUrls: ['./new-device.component.css']
})
export class NewDeviceComponent implements OnInit {

  processing = false;
  disp = 'Add';
  inputs = {
  type: '',
  displayName: '',
  project: '',
  manifest_file: '',
  model_name: '',
  };
  @Output() loadNewDevices = new EventEmitter();

  constructor(
    private snackBar: MatSnackBar,
    private branchService: BranchcomparatorapisService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
  }

  addDevice() {
    if (!this.validate()) {
      this.snackBar.open('Please check the inputs!', 'X', {
        duration: 3000
      });
      return;
    }
    this.processing = true;
    this.disp = 'Adding...';
    this.branchService.addDevice(this.inputs).subscribe(data => {
      console.log(data);
      this.processing = false;
      this.disp = 'Add';
      const dialodRef = this.dialog.open(ExecutionStatusDialogComponent, {
        width: '250px',
        data: {
          status: data.status,
          message: data.message
        }
      });
      if (data.status) {
        this.reset();
        this.loadNewDevices.emit(null);
      }
    },
    (error: any) => {
          this.processing = false;
          this.disp = 'Add';
          //this.reset();
          if (error.status === 500) {
            this.snackBar.open('Something went wrong!', 'X', {
              duration: 10000
            });
          }else{
            this.snackBar.open(error.message, 'X', {
              duration: 10000
            });
          }
        });
  }

  validate() {
    if (
      this.inputs.type === '' ||
      this.inputs.displayName === '' ||
      this.inputs.manifest_file === '' ||
      this.inputs.project === '' ||
      this.inputs.model_name === ''
    ) {
      return false;
    }
    return true;
  }

  reset() {
    this.inputs = {
    type: '',
    displayName: '',
    project: '',
    manifest_file: '',
    model_name: ''
    };
  }
}
