export const environment = {
  production: true,
  clientId: '76d870cc-1a5c-465c-bddc-c55bd6e4c9ac',
  authority: 'https://login.microsoftonline.com/906aefe9-76a7-4f65-b82d-5ec20775d5aa',
  redirectUrl: 'https://10.6.5.163/',
};
